package nl.rug.aoop.asteroids.view.menus;


public interface MenuBlueprint {
    void refresh();
}
