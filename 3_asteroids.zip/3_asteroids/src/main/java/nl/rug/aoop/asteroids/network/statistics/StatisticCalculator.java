package nl.rug.aoop.asteroids.network.statistics;

public interface StatisticCalculator {

}
