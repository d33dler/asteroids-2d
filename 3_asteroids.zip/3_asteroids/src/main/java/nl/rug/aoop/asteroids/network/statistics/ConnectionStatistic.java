package nl.rug.aoop.asteroids.network.statistics;

public class ConnectionStatistic implements StatisticCalculator {

}
