package nl.rug.aoop.asteroids.network;

public record ConfigCodes() {
    public static String PACKET_SIZE  = "packet_size";
}
