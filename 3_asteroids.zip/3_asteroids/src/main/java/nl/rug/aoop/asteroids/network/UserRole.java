package nl.rug.aoop.asteroids.network;

public enum UserRole {
    SERVER,
    CLIENT;

    UserRole() {}

}
